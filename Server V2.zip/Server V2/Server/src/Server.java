import java.io.IOException;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.nio.file.Path;
import java.nio.file.Paths;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import com.sun.net.httpserver.HttpServer;
import com.sun.net.httpserver.SimpleFileServer;



//El objetivo de este servidor es que puedas trabajar con HTLM, CSS Y JAVASCRIPT mediante el mismo
public class Server{
    
    private int port;
    private HttpServer sv;
    
    public static void main(String[] args) throws Exception {

        Server sv = new Server();
        Server.init(sv);

                
    }

    public Server() throws IOException{

        //Establecemos el puerto y creamos nuestro servidor http Local
        this.port = 9000;
        this.sv = HttpServer.create(new InetSocketAddress(port), 0);
        sv.createContext("/check", new RootHandler()); // Permite saber si el servidor fue iniciado correctamente
        sv.createContext("/paginaWeb", new HtmlHandler());

        Path path = Paths.get("C:/Users/Android/Documents/Proyectos Propios en java/Server V2/Server/src");
        var sev = SimpleFileServer.createFileHandler(path); //Usamos un manipulador de tipo SimpleFIleServer

        
        String localIpAdress = InetAddress.getLocalHost().getHostAddress();
        String HostName = InetAddress.getLocalHost().getHostName();
        
        
        sv.createContext("/", sev);
        sv.setExecutor(null);
        
        
        System.out.println("El nombre del host es: " + HostName);
        System.out.println("La direccion Ip del host es: " + localIpAdress);
        

        

    }

    public static void init(Server sev){

        sev.sv.start();
    }


    class RootHandler implements HttpHandler{

        @Override
        public void handle(HttpExchange exchange) throws IOException {
           
            //HttpContext context = exchange.getHttpContext();
            
            String init = "Servidor Local iniciado exitosamente";
            //String method = exchange.getRequestMethod();
        
        
        
            exchange.sendResponseHeaders(200, init.length());
            OutputStream os  = exchange.getResponseBody();
        
            
            os.write(init.getBytes());
            os.close();

        }


    }




}
