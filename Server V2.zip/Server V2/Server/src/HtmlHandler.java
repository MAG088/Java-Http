import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.OutputStream;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;



public class HtmlHandler implements HttpHandler {


    //------------------------------------------ Manipulador Html -------------------------------------------------------------
    @Override
    public void handle(HttpExchange exchange) throws IOException {
        
        //------------------------------------- Leer el archivo html ----------------------------------------------------
        String cadena = "";
        String html = "";
        FileReader file = new FileReader("src/Pagina.html");
        BufferedReader bf = new BufferedReader(file);

        while ((cadena = bf.readLine()) != null) {
            html += cadena;
               
        }

    
        bf.close();

        System.out.println("La direccion remota es: " + exchange.getRemoteAddress());
        

        exchange.sendResponseHeaders(200, 0); // 200 aceptar la respuesta
        OutputStream os = exchange.getResponseBody();

        os.write(html.getBytes());
        os.close();

        
    }
    


}
