
/*--------------------------------------------- Documento JavaScript de prueba -----------------------------------------*/


function setTitle() {

    document.getElementById("titulo").innerHTML = "He cambiado";
    
}

document.getElementById("button").onclick = function name() {
    setTitle();
}


